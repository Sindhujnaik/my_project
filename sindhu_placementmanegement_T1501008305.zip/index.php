<h2>Placement Management System</h2>
<a href="admin/login.php">Admin Login</a>
