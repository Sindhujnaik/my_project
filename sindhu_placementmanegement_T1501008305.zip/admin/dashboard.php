<?php
session_start();
if(!isset($_SESSION['admin'])){
    header("Location: login.php");
}
?>

<h2>Welcome Admin (Sindhu)</h2>
<a href="logout.php">Logout</a>
